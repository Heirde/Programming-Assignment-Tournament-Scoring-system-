#Welcome To my Tournament scoreboard system

#Lists for user to add data to
teams = []
individuals = []
scores_team = []
scores_individual = []
team_ranks = []
individual_ranks = []
team_players = []

#Here I built the leaderboard system for both team and individual
def team_leaderboard():
    global teams, scores_team, team_ranks
    team_data = list(zip(teams, scores_team, team_ranks))
    team_data.sort(key = lambda x: x[1], reverse = True)

    for (team, score, rank) in team_data:
        print(f"Team: {team}. Scored: {score} points and their rank is: {rank}")
        seperator()

def individual_leaderboard():
    global individuals, scores_individual, individual_ranks
    individual_data = list(zip(individuals, scores_individual, individual_ranks))
    individual_data.sort(key = lambda x: x[1], reverse = True)
  
    for (individual, score, rank) in individual_data:
        print(f"Team: {individual}. Scored: {score} points and their rank is {rank}")
        seperator()

#Here I built the score systems for both team and individual        
def team_score_system():
        global teams, scores_team, team_ranks
        print("Teams:", teams)
        seperator()
        for i in range(4):
            print("What was the score for team", i + 1,"Score between 1 - 20")
            score_add = int(input(":> "))
            if score_add <=5:
                rank_team = "Rank 4"
            elif score_add <=10:
                rank_team = "Rank 3"
            elif score_add <=15:
                rank_team = "Rank 2"
            else:
                rank_team = "Rank 1"
            team_ranks.append(rank_team)
            seperator()
            scores_team.append(score_add)
        team_leaderboard()   

def individual_score_system():
    global individuals, scores_individual, individual_ranks
    print("Individuals:", individuals)
    seperator()
    for i in range(20):
        print("What was individual", i + 1, "score (Score between 1 - 20)")
        score_add = int(input(":> "))
        if score_add <=5:
            rank_individual = "Rank 4"
        elif score_add <=10:
            rank_individual = "Rank 3"
        elif score_add <=15:
            rank_individual = "Rank 2"
        else:
            rank_individual = "Rank 1"
        individual_ranks.append(rank_individual)
        seperator()
        scores_individual.append(score_add)
    individual_leaderboard()

#Seperator line function with lambda
seperator = lambda: print("=" * 60)

#Welcome message
seperator()
print("=== WELCOME TO THE TOURNAMENT SCOREBOARD! ===")
seperator()

#Team Section
def team_events(): 
        event_team_amount = int(input("Do you want to run a 1. single event or 2. five events?: "))
        if event_team_amount == 1:
            eventamount = 1
        elif event_team_amount == 2:
            eventamount = 5
        else:
            print("You can only type 1 for a single event and 2 for five events!!!")

        for i in range(eventamount):
            i +=1
            print("This is event ",i)
            for i in range(4):
                add_teams = input("What are your team names?(Enter one team at a time and press enter!!):> ")
                seperator()
                teams.append(add_teams)
                for i in range(5):
                    i += 1
                    add_players = input("What is the name of your player?(Will repeat 5 times add one player at a time!!!):> ")
                    seperator()
                    team_players.append(add_players)
                
            print("Team: ",teams[0], "has the players: ", team_players[0:4])                    
            print("Team: ",teams[1], "has the players: ", team_players[5:9])                     
            print("Team: ",teams[2], "has the players: ", team_players[10:14])
            print("Team: ",teams[3], "has the players: ", team_players[15:19])

            while True:
                event_type = input("What is the event?(Esports, Sports, Educational (Maths, Science etc),Coding(Has to be spelled exactly!!!):> ").lower()
                if event_type in ["esports", "sports", "educational", "coding"]:
                    if event_type == "esports":
                        esports_type = int(input("Which game(1.Fortnite, 2.Call of Duty, 3. Apex legends, 4.CSGO,CS2)? :"))
                    elif event_type == "sports":
                        sports_type = int(input("Which sport(1.Football, 2.Rugby, 3.Cricket, 4. Table tennis, 5.Volleyball)?: "))
                    elif event_type == "Educational":
                        educational_type = int(input("Which education(1.Maths, 2.English, 3.Science, 4.Computer Science, 5.History)?: "))
                    elif event_type == "coding":
                        coding_type = int(input("Which type of code(1.Java, 2.HTML, 3.Python, 4.C++, 5. JavaScript)?: "))
                    break
                elif event_type not in ["esports", "sports", "educational", "coding"]:
                    for i in range(4):
                        i += 1
                        print("attempt", i)
                        print("Incorrect input. Please enter one of the following: esports", "sports", "educational", "coding")

                        if i == 3:
                            print("Exiting the program due to many failed attempts")
                            exit()
                            
                        print("Please Try again") 
                    
                        event_type = input("What is the event?(Esports, Sports, Educational (Maths, Science etc),Coding(Has to be spelled exactly!!!):> ").lower()
                        if event_type in ["esports", "sports", "educational", "coding"]:
                            break   
                    break
                
            team_score_system()
        individual_event_yesorno = input("Would you like to do an individual event?: ").lower()
        if individual_event_yesorno == "Yes":
            individual_events()
        else:
            print("Okay see you later!")

#Individual Section
def individual_events():
        event_individual_amount = int(input("Do you want to run a 1. single event or 2. five events?: "))
        if event_individual_amount == 1:
            event_amount = 1
        elif event_individual_amount == 2:
            event_amount = 5
        else:
            print("You can only type 1 for a single event and 2 for five events!!!")
        for i in range(event_amount):
                i += 1
                print("This is event ",i)
                for i in range(20):
                    add_individuals = input("What is the name of your individual?(Will repeat 20 times, add one person at a time!!)> ")
                    seperator()
                    individuals.append(add_individuals)
                while True:
                    event_type = input("What is the event?(Esports, Sports, Educational (Maths, Science etc),Coding(Has to be spelled exactly!!!):> ").lower()
                    if event_type in ["esports", "sports", "educational", "coding"]:
                        if event_type == "esports":
                            esports_type = int(input("Which game(1.Fortnite, 2.Call of Duty, 3. Apex legends)? :"))
                        elif event_type == "sports":
                            sports_type = int(input("Which sport(1.Football, 2.Rugby, 3.Cricket, 4. Table tennis, 5.Volleyball)?: "))
                        elif event_type == "Educational":
                            educational_type = int(input("Which education(1.Maths, 2.English, 3.Science, 4.Computer Science, 5.History)?: "))
                        elif event_type == "coding":
                            coding_type = int(input("Which type of code(1.Java, 2.HTML, 3.Python, 4.C++, 5. JavaScript)?: "))
                        break
                    elif event_type not in ["esports", "sports", "educational", "coding"]:
                        for i in range(4):
                            i += 1
                            print("attempt", i)
                            print("Incorrect input. Please enter one of the following: esports", "sports", "educational", "coding")

                            if i == 3:
                                print("Exiting the program due to many failed attempts")
                                exit()
                                
                            print("Please Try again")   
                            
                            event_type = input("What is the event?(Esports, Sports, Educational (Maths, Science etc),Coding(Has to be spelled exactly!!!):> ").lower()
                            if event_type in ["esports", "sports", "educational", "coding"]:
                                break   
                        break
                    
                individual_score_system() 
        team_event_yesorno = input("Would you like to do an individual event?: ").lower()
        if team_event_yesorno == "Yes":
            team_events()
        else:
            print("Okay see you later!")

#Picking whether it is team or individual event
team_type = int(input("Are these 1.team or 2.individual events? (input 1 for Teams or 2 for Individuals):>"))
if team_type == 1: 
    team_events()
elif team_type == 2:
    individual_events()
#Extra ElSE incase user inputs incorrect number
else:
    seperator()
    print("incorrect input. (Can only be either 1.team or 2.individual!")
    seperator()
seperator()